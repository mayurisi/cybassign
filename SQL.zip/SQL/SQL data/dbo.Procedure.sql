﻿--CREATE PROCEDURE [dbo].[Procedure]
--	@param1 int = 0,
--	@param2 int
--AS
--	SELECT @param1, @param2
--RETURN 0

CREATE PROCEDURE [dbo].[GetBookByCategory11] @categoryName CHAR(20)
AS
BEGIN
	SELECT b.BookId, b.Title, c.categoryName 
	FROM Book as b join Category as c on b.CategoryId = c.categoryId 
	where c.categoryName = @categoryName
END