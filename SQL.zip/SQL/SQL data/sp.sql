SELECT * FROM BOOK
SELECT * FROM Author
SELECT * FROM BookAuthor
SELECT * FROM Category

CREATE PROCEDURE GetBookByCategory
AS
BEGIN
	SELECT b.BookId, b.Title, c.categoryName 
	FROM Book as b join Category as c on b.CategoryId = c.categoryId 
	where c.categoryName='Technical'
END

GetBookByCategory

CREATE PROCEDURE GetBookByAuthorCategory
AS
BEGIN
	SELECT BookId, Title FROM Book where CategoryId IN 
	(SELECT CategoryId FROM Category WHERE categoryName = 'Technical') AND BookId IN
	(SELECT BookId FROM BookAuthor where AuthorId IN 
	(SELECT AuthorId FROM Author WHERE AuthorName = 'Yashvant Kanitkar'))

END

