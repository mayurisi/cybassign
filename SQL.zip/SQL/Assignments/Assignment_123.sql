---DROP DATABASE IF ALREADY EXISTS
drop database BookStoreDB

--CREATE DATABASE 
create database BookStoreDB

--USE DATABASE
use BookStoreDB

--CREATE TABLE WITH PRIMARY CONSTRAINTS
create table Category(categoryId INT PRIMARY KEY NOT NULL,
categoryName VARCHAR(30) NOT NULL,
Description VARCHAR(30))

create table Author(AuthorId INT identity(1,1) PRIMARY KEY,
AuthorName VARCHAR(20) NOT NULL,
DateOfBirth DATE,
State VARCHAR(20), 
City VARCHAR(20), 
Phone BIGINT)

create table Publisher(PublisherId INT identity(1,1) PRIMARY KEY,
PublisherName VARCHAR(20) NOT NULL,
DateOfBirth DATE,
State VARCHAR(20), 
City VARCHAR(20), 
Phone BIGINT)

create table Book(BookId INT PRIMARY KEY,
Title VARCHAR(30),
[Description] VARCHAR(30),
Price INT,
ISBN VARCHAR(10),
PublicationDate Date)

create table [Order](OrderId INT PRIMARY KEY,
Order_Date Date NOT NULL,
BookId INT NOT NULL,
Quantity INT NOT NULL,
UnitPrice INT NOT NULL,
Shipping_Address VARCHAR(30) NOT NULL)

-------------------------------------------------------------------

--MANY TO MANY RELATIONSHIP BETWEEN BOOKS AND AUTHORS IS ESTABLISHED USING LINKER TABLE

DROP TABLE BookAuthor

create table BookAuthor(
BookId int NOT NULL,
AuthorId int NOT NULL)

ALTER TABLE BookAuthor ADD
FOREIGN KEY(BookId) REFERENCES Book(BookId) on update cascade,
FOREIGN KEY(AuthorId) REFERENCES Author(AuthorId) on update cascade

--CREATING COMPOSITE PRIMARY KEY FOR LINKER TABLE
ALTER TABLE BookAuthor ADD CONSTRAINT pk_Book_Author PRIMARY KEY(BookId,AuthorId)

ALTER TABLE Book ADD CategoryId int
FOREIGN KEY(CategoryId) REFERENCES Category(CategoryId) on update cascade 

ALTER TABLE Book ADD PublisherId int
FOREIGN KEY(PublisherId) REFERENCES Publisher(PublisherId) on update cascade

ALTER TABLE [Order] ADD
FOREIGN KEY(BookId) REFERENCES Book(BookId) on update cascade


--INSERT DATA INTO TABLES AS PER SPECIFIED CONSTRAINTS
INSERT INTO Category VALUES(201,'Biography','Biography of a person'),
(202,'Science Fiction','Scientific future views'),
(203,'Criminal Cases','Solving cases'),
(204,'Technical','Technologies')

select * from Category

INSERT INTO Author values('Abdul Kalam','1960-5-23','Tamilnadu','xyz',4567891230)
INSERT INTO Author values('H C Verma','1960-7-2','Maharashtra','Pune',5667891230),
('Harris','1989-5-12','Kerala','abc',45632891230),
('Connen Doyle','2000-5-23','MP','Bhopal',4567891230),
('Yashvant Kanitkar','1983-4-5','UP','xy',9845623514)

select * from Author

insert into Publisher values('Techmax','2000-12-5','Maharashtra','Pune',9654871235)
insert into Publisher values('Technical','2012-12-5','Maharashtra','Pune',8754871235)
insert into Publisher values('MacGrow Hill','2008-1-9','MP','Bhopal',9654871235)
insert into Publisher values('Pearson','1980-12-5','Gujarat','Surat',9654871235)

select * from Publisher
select * from Category

sp_help Book

INSERT INTO Book values(101,'Wings_of_fire','Biography_of_Abdul_Kalam',200,12546,'2005-12-1',201,3)
INSERT INTO Book values(102,'Modern Physics','H C Verma',200,456789,'2009-1-1',204,1)
INSERT INTO Book values(103,'Harry Potter','Harris',500,123789,'1990-12-8',202,3)
INSERT INTO Book values(104,'Adventures of Sherlock Holmes','Connen Doyle',300,25896,'2005-4-1',203,4)
INSERT INTO Book values(105,'Let us C','Yashvant Kanitkar',300,55896,'2005-7-11',204,2)

select * from Book

--DESCRIBING TABLE 
sp_help [Order]

insert into [Order] values(1,'2016-12-6',101,2,200,'Pune')
insert into [Order] values(2,'2015-2-16',102,4,200,'Chennai')
insert into [Order] values(3,'2013-10-26',103,5,500,'Mumbai')
insert into [Order] values(4,'2016-2-17',104,1,300,'Delhi')
insert into [Order] values(5,'2015-10-22',105,1,300,'Banglore')
insert into [Order] values(6,'2015-9-25',102,1,200,'Calcutta')

select * from [Order]


INSERT INTO BookAuthor values(101,1),(102,2),(102,5),(103,3),(103,4),(104,4),(105,5),(105,4)
select * from BookAuthor


--------------------------------------------------------------------------------------

select * from Book
select * from Author

select * from BookAuthor

select AuthorId from Author where AuthorName='Connen Doyle'
select BookId from BookAuthor where AuthorId=4

--USING SUB QUERIES CONCEPT
select Title from Book where 
BookId IN(select BookId from BookAuthor where AuthorId IN
(select AuthorId from Author where AuthorName='Connen Doyle'))


------------------------------
select * from Category
select * from Publisher
select * from Book
select * from Author

select CategoryId from Category where categoryName='Technical'
select PublisherId from Book where CategoryId=204
select PublisherName from Publisher where PublisherId=10


select Title from Book where PublisherId IN 
(select PublisherId from Book where CategoryId IN 
(select CategoryId from Category where categoryName='Technical')) AND BookId IN
(select BookId from BookAuthor where AuthorId IN
(select AuthorId from Author where AuthorName='Yashvant Kanitkar'))


---------------------------------------------------

--USING INNER JOIN
select p1.PublisherId,p1.PublisherName,count(BookId) as Book_count from Book b1 JOIN Publisher p1 
ON b1.PublisherId=p1.PublisherId group by p1.PublisherId,p1.PublisherName


---------------------------------------------------

select * from Book
select * from [Order]

select DISTINCT o1.OrderId,o1.BookId,b1.Title from [Order] as o1 JOIN Book as b1 
ON o1.BookId = b1.BookId

---------------------------------------------------