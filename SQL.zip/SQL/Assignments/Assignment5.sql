---DROP DATABASE IF ALREADY EXISTS
drop database TestDB

--CREATE DATABASE 
create database TestDB

--USE DATABASE
use TestDB

create table Book(BookId INT PRIMARY KEY,
Title VARCHAR(30),
[Description] VARCHAR(30),
Price INT,
ISBN VARCHAR(10),
PublicationDate Date)

INSERT INTO Book values(101,'Wings_of_fire','Biography_of_Abdul_Kalam',200,12546,'2005-12-1')
INSERT INTO Book values(102,'Modern Physics','H C Verma',200,456789,'2009-1-1')
INSERT INTO Book values(103,'Harry Potter','Harris',500,123789,'1990-12-8')
INSERT INTO Book values(104,'Adventures of Sherlock Holmes','Connen Doyle',300,25896,'2005-4-1')
INSERT INTO Book values(105,'Let us C','Yashvant Kanitkar',300,55896,'2005-7-11')

SELECT * FROM Book

create table [Order](OrderId INT PRIMARY KEY,
Order_Date Date NOT NULL,
BookId INT NOT NULL,
Quantity INT NOT NULL,
UnitPrice INT NOT NULL,
Shipping_Address VARCHAR(30) NOT NULL)

insert into [Order] values(1,'2016-12-6',101,2,200,'Pune')
insert into [Order] values(2,'2015-2-16',102,4,200,'Chennai')
insert into [Order] values(3,'2013-10-26',103,5,500,'Mumbai')
insert into [Order] values(4,'2016-2-17',104,1,300,'Delhi')
insert into [Order] values(5,'2015-10-22',105,1,300,'Banglore')
insert into [Order] values(6,'2015-9-25',102,1,200,'Calcutta')

select * from [Order]

----------------------------//1//---------------------------------

create table Book_History(BookId INT PRIMARY KEY,
Title VARCHAR(30),
[Description] VARCHAR(30),
Price INT,
ISBN VARCHAR(10),
PublicationDate Date)

CREATE TRIGGER Add_To_Book_History
ON Book
FOR DELETE
AS
BEGIN
DECLARE @BookId INT, 
		@title CHAR(30), 
		@desc CHAR(30), 
		@price INT,
		@isbn INT,
		@pub_date date

SELECT @BookId = BookID, 
	   @title = Title, 
	   @desc = [Description], 
	   @price = Price,
	   @isbn = ISBN,
	   @pub_date = PublicationDate
FROM DELETED

INSERT INTO Book_History
VALUES(@BookId , @title , @desc, @price,@isbn, @pub_date)
PRINT 'Book details added to History table'
END

select * from Book

select * from Book_History

DELETE FROM Book WHERE BookId=102

----------------------------//2//---------------------------------

CREATE TRIGGER Check_Price
ON Book
FOR UPDATE, INSERT
AS
BEGIN
	DECLARE @Price int
	--for insert command
	SELECT @Price = Price FROM inserted

	IF @Price < 1 
	BEGIN
		ROLLBACK
		PRINT 'Invalid Price, statement is terminated'
	END
END

INSERT INTO Book values(102,'Modern Physics','H C Verma',0,456789,'2009-1-1')
INSERT INTO Book values(102,'Modern Physics','H C Verma',200,456789,'2009-1-1')

Update Book
set Price = -1 where BookId = 101

Update Book
set Price = 300 where BookId = 101

select * from Book

----------------------------//3//---------------------------------
