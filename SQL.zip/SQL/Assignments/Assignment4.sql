
-----------------//1//-------------------------------------
CREATE PROCEDURE get_Books_by_Author @AuthorName VARCHAR(20)
AS
BEGIN 
IF @AuthorName IS NOT NULL
	select Title from Book where 
	BookId IN(select BookId from BookAuthor where AuthorId IN
	(select AuthorId from Author where AuthorName=@AuthorName))
ELSE
	PRINT 'Please enter Author Name'
END

--Calling procedure get_Books_by_Author
EXECUTE get_Books_by_Author Harris

-----------------//2//-------------------------------------

CREATE PROCEDURE get_Books_By_Author_publisher
AS
BEGIN 

	select Title from Book where PublisherId IN 
	(select PublisherId from Book where CategoryId IN 
	(select CategoryId from Category where categoryName='Technical')) AND BookId IN
	(select BookId from BookAuthor where AuthorId IN
	(select AuthorId from Author where AuthorName='Yashvant Kanitkar'))

END

--Calling procedure get_Books_By_Author_publisher
EXECUTE get_Books_By_Author_publisher

-----------------//3//-------------------------------------

CREATE PROCEDURE get_Books_By_Each_publisher
AS
BEGIN 
	select p1.PublisherId,p1.PublisherName,count(BookId) as 
	Book_count from Book b1 JOIN Publisher p1 
	ON b1.PublisherId=p1.PublisherId 
	group by p1.PublisherId,p1.PublisherName
END

--Calling procedure get_Books_By_Each_publisher
EXECUTE get_Books_By_Each_publisher

-----------------//4//-------------------------------------

CREATE PROCEDURE Insert_Books 
AS
INSERT INTO Book values
(106,'Complete Java Reference','About Java',500,18569,'1995-12-1',204,2)

EXECUTE Insert_Books
select * from Book

-----------------//5//-------------------------------------

CREATE PROCEDURE Update_Books @Bookid INT, @title varchar(30)
AS 
BEGIN
UPDATE Book SET Title=@title where BookId=@Bookid
END

EXECUTE Update_Books 106 ,'Java Reference Edition 6'
select * from Book

-----------------//6//-------------------------------------
DROP PROCEDURE delete_Books_by_Id

ALTER PROCEDURE delete_Books_by_Id @Bookid INT
AS 
BEGIN
DELETE FROM Book WHERE BookId=@Bookid
END

SELECT * FROM BookAuthor

EXECUTE delete_Books_by_Id 105