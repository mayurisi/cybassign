drop database BookStoreDB
create database BookStoreDB

use BookStoreDB

create table Category(categoryId INT PRIMARY KEY NOT NULL,
categoryName VARCHAR(30) NOT NULL,
Description VARCHAR(30))

insert into Category values(201,'Biography','Biography of a person'),
(202,'Science Fiction','Scientific future views'),
(203,'Criminal Cases','Solving cases')
(204,'Technical','Technologies')

select * from Category

create table Author(AuthorId INT identity(1,1) PRIMARY KEY,
AuthorName VARCHAR(20) NOT NULL,
DateOfBirth DATE,
State VARCHAR(20), 
City VARCHAR(20), 
Phone BIGINT)

INSERT INTO Author values(1,'Abdul Kalam','1960-5-23','Tamilnadu','xyz',4567891230)
INSERT INTO Author values(2,'H C Verma','1960-7-2','Maharashtra','Pune',5667891230),
(3,'Harris','1989-5-12','Kerala','abc',45632891230),
(4,'Connen Doyle','2000-5-23','MP','Bhopal',4567891230),
(5,'Yashvant Kanitkar','1983-4-5','UP','abc',9845623514)

select * from Author

drop table Publisher
create table Publisher(PublisherId INT identity(1,1) PRIMARY KEY,
PublisherName VARCHAR(20) NOT NULL,
DateOfBirth DATE,
State VARCHAR(20), 
City VARCHAR(20), 
Phone BIGINT)

insert into Publisher values(1011,'Techmax','2000-12-5','Maharashtra','Pune',9654871235),
(1012,'Technical','2012-12-5','Kerala','abc',8754871235),
(1013,'MacGrow Hill','2008-15-9','UP','xyz',9654871235),
(1014,'Pearson','1980-12-5','Gujarat','Surat',9654871235)

SELECT * FROM Publisher

drop table Book
create table Book(BookId INT PRIMARY KEY,
Title VARCHAR(30),
Description VARCHAR(30),
Price INT,
ISBN VARCHAR(10),
PublicationDate Date)

alter table Book ADD CategoryId int
FOREIGN KEY(CategoryId) REFERENCES Category(CategoryId) on delete cascade on update cascade 

alter table Book ADD PublisherId int
FOREIGN KEY(PublisherId) REFERENCES Publisher(PublisherId) on delete cascade on update cascade 

update Book set CategoryId=201 where BookId=101
update Book set CategoryId=202 where BookId=102
update Book set CategoryId=202 where BookId=103
update Book set CategoryId=203 where BookId=104

select * from Book

update Book set PublisherId=203 where BookId=104

select * from Book

drop table BookAuthor

create table BookAuthor(BookId int,AuthorId int,
FOREIGN KEY(BookId) REFERENCES Book(BookId) on delete cascade on update cascade,
FOREIGN KEY(AuthorId) REFERENCES Author(AuthorId) on delete cascade on update cascade)

select * from Author
select * from Book
INSERT INTO BookAuthor values(101,2),(102,3),(102,4),(103,4),(103,5),(104,5)
select * from BookAuthor

INSERT INTO Book values(101,'Wings_of_fire','Biography_of_Abdul_Kalam',200,12546,'2005-12-1')
INSERT INTO Book values(102,'Modern Physics','H C Verma',200,456789,'2009-1-1'),
(103,'Harry Potter','Harris',500,123789,'1990-12-8'),
(104,'Adventures of Sherlock Holmes','Connen Doyle',300,25896,'2005-4-1')

select * from Book
sp_help 'dbo.Book'

DROP TABLE Orders
create table Orders(OrderId INT PRIMARY KEY,
Order_Date Date NOT NULL,
BookId INT NOT NULL,
Quantity INT NOT NULL,
UnitPrice INT NOT NULL,
Shipping_Address VARCHAR(30) NOT NULL,
FOREIGN KEY(BookId) REFERENCES Book(BookId) on delete cascade on update cascade)

insert into Orders values(1,'2016-12-6',101,2,200,'Karvenagar,Pune')
insert into Orders values(2,'2015-2-16',102,4,200,'ShantiNagar,Pune')
insert into Orders values(3,'2013-10-26',103,5,500,'Mumbai')
insert into Orders values(4,'2015-9-1',104,1,300,'Delhi')

update Orders set Order_Date='2014-12-6' where Order_Date='2016-12-6'

select * from Orders
