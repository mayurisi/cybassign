Use eShop

SELECT iEmployeeId,
	cJobTitle as 'Designation',
	dBirthDate as 'Date of Birth'
FROM Employee

select * from Employee

select cTitle + '' + cFirstName + '' + cLastName AS 'Name' FROM Employee

select cTitle  + cFirstName  + cLastName AS 'Name' FROM Employee

select iProductId,iUnitPrice,(iUnitPrice - (iUnitPrice*.1))as 'DiscountPrice' FROM Product

select * from Product

select cJobTitle FROM Employee

select distinct cJobTitle FROM Employee

select TOP 2 iUnitPrice,cProductName from Product order by iUnitPrice DESC

select TOP 25 PERCENT cDepartmentName from Department -- assuming each row having 25% share for 4 rows

select TOP 50 PERCENT iUnitPrice as 'MRP',cProductName as 'MobilePhone' from Product order by iUnitPrice DESC 

select * from Department

select DB_ID('eShop')  --Returns Database ID

select DB_NAME(10)	--returns db name

select @@VERSION	--returns sql version

select * from sys.database_files

select iProductId,cProductName,iUnitPrice from Product where iUnitPrice > 35000

select iProductId,cProductName,iUnitPrice from Product where iUnitPrice between 35000 and 40000

select iProductId,cProductName,iUnitPrice from Product where iUnitPrice >= 35000 and iUnitPrice <= 40000

select iProductId,cProductName,iUnitPrice from Product where iUnitPrice NOT between 35000 and 40000

select iEmployeeId,cTitle,cFirstName,cCity from Employee where cCity IN('Pune','Ahmedabad')

select iEmployeeId,cTitle,cFirstName,cCity from Employee where cCity NOT IN('Pune','Ahmedabad')

select iEmployeeId ,cTitle,cFirstName,cCity from Employee where cFirstName LIKE 'sa%' 

select iEmployeeId ,cTitle,cFirstName,cCity from Employee where cFirstName LIKE '_a%'

select iEmployeeId ,cTitle,cFirstName,cCity from Employee where cFirstName LIKE '[a-c]%' --starting with the letter in specified in range

select iEmployeeId ,cTitle,cFirstName,cCity from Employee where cFirstName LIKE '[^a-c]%'

select iEmployeeId,cTitle,cFirstName,cCity from Employee where cCity is NULL

select iEmployeeId,cTitle,cFirstName,cCity from Employee where cCity is NOT NULL

select iEmployeeId ,cTitle,cFirstName,cCity from Employee

select * from Employee

select min(iUnitPrice) as 'min_price' from Product

select * from Orders

select iProductId,sum(iQuantity) as 'Quantity_sold' from Orders 
group by iProductId
order by iProductId

select iCustomerId,iProductId ,sum(iQuantity) as 'Quantity_sold' from Orders 
group by iCustomerId,iProductId
with ROLLUP


select iCustomerId,iProductId ,sum(iQuantity) as 'Quantity_sold' from Orders 
group by iCustomerId,iProductId
with cube
select * from Orders

select iProductId,sum(iQuantity) AS "Quantity_sold" from Orders 
GROUP BY iProductId HAVING sum(iQuantity)>2   --eliminates groups not individual rows, applies to groups only
ORDER BY iProductId
select * from Orders

select cState From Employee

select cState From Customer

select cState From Employee
UNION
select cState From Customer -- returns distict rows in ascending order

select cState From Employee
UNION ALL
select cState From Customer -- returns distict all rows not in particular order

select cState From Employee
EXCEPT
select cState From Customer -- (query1 - query2) result

select cState From Employee
INTERSECT
select cState From Customer -- common betn 2 tables

CREATE TABLE table1(ID int,Value VARCHAR(10))

INSERT INTO table1 values(1,'First'),(2,'Second'),(3,'Third'),(4,'Fourth'),(5,'Fifth')

CREATE TABLE table2(ID int,Value VARCHAR(10))

INSERT INTO table2 values(1,'First'),(2,'Second'),(3,'Third'),(6,'Sixth'),(7,'Seventh'),(8,'Eightth')

select t1.*,t2.* from table1 t1 join table2 t2 on t1.ID = t2.ID

select t1.*,t2.* from table1 t1 LEFT OUTER JOIN table2 t2 on t1.ID = t2.ID

select t1.*,t2.* from table1 t1 RIGHT OUTER JOIN table2 t2 on t1.ID = t2.ID

select t1.*,t2.* from table1 t1 FULL OUTER JOIN table2 t2 on t1.ID = t2.ID

SELECT emp1.iEmployeeId,emp1.cFirstName as "Employee",
emp2.cFirstName as "Manager"
FROM Employee as emp1 INNER JOIN Employee as emp2
on emp1.iManagerId =  emp2.iEmployeeId
select * from Employee