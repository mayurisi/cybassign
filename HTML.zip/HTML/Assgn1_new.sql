drop database BookStoreDB

create database BookStoreDB

use BookStoreDB

create table Category(categoryId INT PRIMARY KEY NOT NULL,
categoryName VARCHAR(30) NOT NULL,
Description VARCHAR(30))

create table Author(AuthorId INT identity(1,1) PRIMARY KEY,
AuthorName VARCHAR(20) NOT NULL,
DateOfBirth DATE,
State VARCHAR(20), 
City VARCHAR(20), 
Phone BIGINT)

create table Publisher(PublisherId INT identity(1,1) PRIMARY KEY,
PublisherName VARCHAR(20) NOT NULL,
DateOfBirth DATE,
State VARCHAR(20), 
City VARCHAR(20), 
Phone BIGINT)

create table Book(BookId INT PRIMARY KEY,
Title VARCHAR(30),
Description VARCHAR(30),
Price INT,
ISBN VARCHAR(10),
PublicationDate Date,
[Image] varchar(10))

create table [Order](OrderId INT PRIMARY KEY,
Order_Date Date NOT NULL,
BookId INT NOT NULL,
Quantity INT NOT NULL,
UnitPrice INT NOT NULL,
Shipping_Address VARCHAR(30) NOT NULL,
FOREIGN KEY(BookId) REFERENCES Book(BookId) on update cascade)

-------------------------------------------------------------------
DROP TABLE BookAuthor

create table BookAuthor(
BookId int NOT NULL,
AuthorId int NOT NULL)

ALTER TABLE BookAuthor ADD
FOREIGN KEY(BookId) REFERENCES Book(BookId) on delete cascade on update cascade,
FOREIGN KEY(AuthorId) REFERENCES Author(AuthorId) on delete cascade on update cascade

ALTER TABLE BookAuthor ADD CONSTRAINT pk_Book_Author PRIMARY KEY(BookId,AuthorId)

ALTER TABLE Book ADD CategoryId int
FOREIGN KEY(CategoryId) REFERENCES Category(CategoryId) on update cascade 

ALTER TABLE Book ADD PublisherId int
FOREIGN KEY(PublisherId) REFERENCES Publisher(PublisherId) on update cascade

INSERT INTO Category VALUES(201,'Biography','Biography of a person'),
(202,'Science Fiction','Scientific future views'),
(203,'Criminal Cases','Solving cases'),
(204,'Technical','Technologies')

select * from Category

INSERT INTO Author values(1,'Abdul Kalam','1960-5-23','Tamilnadu','xyz',4567891230),
(2,'H C Verma','1960-7-2','Maharashtra','Pune',5667891230),
(3,'Harris','1989-5-12','Kerala','abc',45632891230),
(4,'Connen Doyle','2000-5-23','MP','Bhopal',4567891230),
(5,'Yashvant Kanitkar','1983-4-5','UP','abc',9845623514)